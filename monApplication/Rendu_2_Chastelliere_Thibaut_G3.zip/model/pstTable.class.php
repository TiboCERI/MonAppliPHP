<?php

class postTable
{
	public static function getPostById()
	{
		$connection= new dbconnection();
		$sql="select * from fredouil.
	}
}
